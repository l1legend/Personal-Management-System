﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using $safeprojectname$.General;

namespace $safeprojectname$.Forms
{
    public partial class AddRolesForm : TemplateForm
    {
        public AddRolesForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show(AppConnection.GetConnectionString());
        }
    }
}
